import React from 'react';

interface WalletButtonProps {
  onClick: () => void;
  connected: boolean;
}

const WalletButton: React.FC<WalletButtonProps> = ({ onClick, connected }) => {
  return (
    <button
      onClick={onClick}
      className={`
        group
        relative
        flex items-center gap-4
        bg-[#C0C0C0] /* Classic GB Grey */
        text-[#00008b] /* Classic Logo Blue */
        font-press-start text-[10px] md:text-xs tracking-wider font-bold
        py-3 px-5
        rounded-lg /* Even corners */
        /* Plastic Bevel Effect */
        border-t-[3px] border-l-[3px] border-[#e0e0e0]
        border-b-[3px] border-r-[3px] border-[#808080]
        shadow-xl
        transform transition-all duration-75
        
        /* Interactive States */
        hover:bg-[#d0d0d0]
        active:border-t-[#808080] active:border-l-[#808080] 
        active:border-b-[#e0e0e0] active:border-r-[#e0e0e0]
        active:translate-y-[2px]
      `}
    >
      {/* Battery LED Indicator */}
      <div className="flex items-center gap-2">
         <div 
           className={`
             w-3 h-3 rounded-full border border-black/30 shadow-inner transition-colors duration-300
             ${connected ? 'bg-[#ff0000] shadow-[0_0_6px_#ff0000]' : 'bg-[#505050]'}
           `}
         />
         <span className="text-[8px] opacity-60 font-sans font-bold tracking-tight text-black hidden sm:block">BATTERY</span>
      </div>

      <span className="uppercase">
        {connected ? 'LINKED' : 'CONNECT'}
      </span>
    </button>
  );
};

export default WalletButton;
