import React from 'react';
import WalletButton from './WalletButton';

interface GameUIProps {
  onConnect: () => void;
  isConnected: boolean;
}

const GameUI: React.FC<GameUIProps> = ({ onConnect, isConnected }) => {
  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-4 md:p-10">
      
      {/* Wallet Connect Button - Strictly Absolute Top Right */}
      {/* Placed outside the relative flow to ensure corner anchoring regardless of text size */}
      <div className="pointer-events-auto absolute top-4 right-4 md:top-10 md:right-10 z-50">
           <WalletButton onClick={onConnect} connected={isConnected} />
      </div>

      {/* Top Header Section */}
      <div className="relative w-full mt-2 md:mt-0">
        
        {/* Branding / Hero Title - Left Aligned */}
        {/* max-w ensures it doesn't overlap the button on very small screens */}
        <div className="pointer-events-auto flex flex-col items-start z-10 relative max-w-[60%] md:max-w-[70%]">
            <h1 className="font-press-start text-3xl md:text-6xl text-[#C0C0C0] italic tracking-tighter drop-shadow-lg leading-none"
                style={{ 
                  textShadow: '4px 4px 0px #0f380f',
                  WebkitTextStroke: '1px #0f380f'
                }}>
                GORBOY
            </h1>
            <div className="flex items-center gap-2 md:gap-3 mt-2 pl-1">
                <div className="h-[3px] md:h-[4px] w-6 md:w-8 bg-[#00008b] rounded-full shadow-sm"></div>
                <div className="h-[3px] md:h-[4px] w-6 md:w-8 bg-[#8b1d2d] rounded-full shadow-sm"></div>
                <span className="font-sans font-bold italic text-[#C0C0C0] text-lg md:text-2xl tracking-[0.2em] drop-shadow-md">
                    GAME
                </span>
            </div>
        </div>

      </div>

      {/* Bottom Hints (Footer) */}
      <div className="w-full text-center pb-4 opacity-75">
        <div className="inline-block bg-[#0f380f]/80 px-4 py-2 rounded-md border border-[#9bbc0f]/30 backdrop-blur-sm shadow-lg">
            <p className="font-press-start text-[10px] text-[#9bbc0f] animate-pulse">
            PRESS START TO INTERACT
            </p>
        </div>
      </div>
    </div>
  );
};

export default GameUI;