import React from 'react';

const RetroGrid: React.FC = () => {
  return (
    <>
      <style>
        {`
          @keyframes grid-scroll {
            0% { background-position: 0px 0px; }
            100% { background-position: 0px 80px; }
          }
        `}
      </style>
      <div 
        className="absolute top-[50%] left-1/2 w-[200vw] h-[200vh] -translate-x-1/2 -translate-y-1/2 z-0 pointer-events-none"
        style={{
           transform: 'translate(-50%, -50%) perspective(600px) rotateX(60deg)',
           transformOrigin: 'top center',
           background: `
             linear-gradient(rgba(155, 188, 15, 0.4) 1px, transparent 1px),
             linear-gradient(90deg, rgba(155, 188, 15, 0.4) 1px, transparent 1px)
           `,
           backgroundSize: '80px 80px',
           animation: 'grid-scroll 4s linear infinite',
           maskImage: 'linear-gradient(to bottom, rgba(0,0,0,1) 0%, rgba(0,0,0,0) 80%)',
           WebkitMaskImage: 'linear-gradient(to bottom, rgba(0,0,0,1) 0%, rgba(0,0,0,0) 80%)'
         }}
      >
      </div>
      {/* Horizon glow */}
      <div className="absolute top-[50%] left-0 w-full h-32 bg-gradient-to-t from-[#9bbc0f]/20 to-transparent pointer-events-none z-0" />
    </>
  );
};

export default RetroGrid;