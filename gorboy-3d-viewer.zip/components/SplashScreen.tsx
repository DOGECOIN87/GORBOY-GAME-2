import React, { useEffect, useState } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [isFading, setIsFading] = useState(false);

  useEffect(() => {
    // Start fade out
    const fadeTimer = setTimeout(() => {
      setIsFading(true);
    }, 3000);

    // Complete (unmount)
    const removeTimer = setTimeout(() => {
      onComplete();
    }, 4000);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, [onComplete]);

  return (
    <div 
      className={`fixed inset-0 z-[100] bg-black flex flex-col justify-center items-center text-white transition-opacity duration-1000 ${isFading ? 'opacity-0' : 'opacity-100'}`}
    >
      {/* Placeholder for the image in the prompt, using a CSS approximation if image fails or just the img tag */}
      <div className="relative mb-8">
        <img 
            src="./gorboy-splashscreen.png" 
            alt="Gorboy Logo" 
            className="w-64 h-auto md:w-96 image-pixelated"
            onError={(e) => {
                // Fallback if image is missing
                e.currentTarget.style.display = 'none';
            }}
        />
        {/* Fallback Text if image fails to load or just to enhance */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0">
             <h1 className="text-6xl font-press-start text-[#9bbc0f]">GORBOY</h1>
        </div>
      </div>
      
      <div className="text-xl font-mono tracking-[0.2em] uppercase animate-pulse-fast text-[#9bbc0f]">
        Loading...
      </div>
      
      {/* Copyright text usually found on boot */}
      <div className="absolute bottom-10 text-xs font-mono text-gray-500">
        ©1989-2024 GORBOY INC.
      </div>
    </div>
  );
};

export default SplashScreen;
