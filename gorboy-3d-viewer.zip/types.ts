import React from 'react';

type ModelViewerProps = React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement> & {
  src?: string;
  alt?: string;
  'camera-controls'?: boolean;
  'auto-rotate'?: boolean;
  'camera-orbit'?: string;
  'min-camera-orbit'?: string;
  'max-camera-orbit'?: string;
  'field-of-view'?: string;
  'shadow-intensity'?: string;
  'shadow-softness'?: string;
  'disable-tap'?: boolean;
}, HTMLElement>;

// Augment the global JSX namespace which is safer and supports merging
declare global {
  namespace JSX {
    interface IntrinsicElements {
      'model-viewer': ModelViewerProps;
    }
  }
}

export interface WalletState {
  connected: boolean;
  address: string | null;
}