import React, { useState, useEffect } from 'react';
import RetroGrid from './components/RetroGrid';
import GameUI from './components/GameUI';
import SplashScreen from './components/SplashScreen';

// NOTE: Ensure hitem3d.glb and gorboy-splashscreen.png are in your public folder

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [walletConnected, setWalletConnected] = useState(false);

  const handleWalletConnect = () => {
    // Simulate connection
    setWalletConnected(!walletConnected);
  };

  const handleModelClick = () => {
    console.log('Hit!');
  };

  useEffect(() => {
      // Add event listener to the model viewer element strictly for interaction logic if needed outside React
      // But standard onClick on the element works in React for custom elements usually.
      const modelViewer = document.querySelector('model-viewer');
      if (modelViewer) {
          modelViewer.addEventListener('click', handleModelClick);
      }
      return () => {
          if (modelViewer) {
              modelViewer.removeEventListener('click', handleModelClick);
          }
      }
  }, [showSplash]);

  return (
    <div className="relative w-full h-full bg-[#1a1a1a] overflow-hidden">
      
      {showSplash && (
        <SplashScreen onComplete={() => setShowSplash(false)} />
      )}

      {/* Main Game Scene */}
      <div className={`transition-opacity duration-1000 ${showSplash ? 'opacity-0' : 'opacity-100'}`}>
        
        <RetroGrid />

        <GameUI 
            onConnect={handleWalletConnect} 
            isConnected={walletConnected} 
        />

        {/* 3D Model Viewer */}
        <div className="absolute top-0 left-0 w-full h-full z-0">
            <model-viewer
                src="./hitem3d.glb"
                alt="Gorboy Character"
                camera-controls
                auto-rotate
                camera-orbit="0deg 75deg 105%"
                min-camera-orbit="auto 0deg auto"
                max-camera-orbit="auto 85deg auto"
                field-of-view="30deg"
                shadow-intensity="2"
                shadow-softness="0.4"
                disable-tap
                style={{ width: '100%', height: '100%' }}
            ></model-viewer>
        </div>

      </div>
    </div>
  );
};

export default App;
